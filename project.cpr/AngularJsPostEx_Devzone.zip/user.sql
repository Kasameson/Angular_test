CREATE TABLE `users` (                                   
          `uid` int(11) NOT NULL AUTO_INCREMENT,                 
          `name` varchar(225) DEFAULT NULL,                      
          `email` varchar(225) DEFAULT NULL,                     
          `pass` varchar(225) DEFAULT NULL,                      
          PRIMARY KEY (`uid`)                                    
        ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1  
